from Animation import *
class User:
    def __init__(self, x, y, vx, vy, ay, character, direction, num, actions, state):
        """initiates position, velocity, acceleration, character name, direction facing, which animation, animation list, type of animation""" 
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.ay = ay
        self.character = character
        self.direction = direction
        self.num = num
        self.actions = actions
        self.state = state
        
    def gravity(self, plat):
        """initiates gravity and movement, stops if player is on platform
           parameters: plat = platform
           returns: none"""
        self.x += self.vx
        self.vy += self.ay
        self.y += self.vy
        
        if self.y > plat:
            self.y = plat 
            self.vy = 0
    
    def initiate_action(self):
        """method runs code to animate sprites
           parameters: none
           returns: none""" 
        if self.state == "animate":
            self.actions[self.character][self.direction][self.num].animate(self.x, self.y - self.actions[self.character][self.direction][self.num].image_height)
        else:
            self.actions[self.character][self.direction][self.num].hold(self.x, self.y - self.actions[self.character][self.direction][self.num].image_height)
    
    def moving(self, plat, up, left, right, down, atk, special, shield):
        """based on the controls and position, function will select a sprite
           parameters: plat = platform, up = boolean (keypressed), left = boolean (keypressed), right = boolean (keypressed), down = boolean (keypressed), 
                                        atk = = boolean (keypressed), special = boolean (keypressed), shield = boolean (keypressed)     
           returns: none"""
        
        self.gravity(plat)
        self.initiate_action()
        
        #jumping
        if up and not(atk or special):
            self.state = "hold"
            if self.y == plat:
                self.vy -= 45
            if left:
                self.vx = -20
            if right: 
                self.vx = 20
            self.num = 5
            if self.actions[self.character][self.direction][5].counter == self.actions[self.character][self.direction][5].counter_limit:
                self.vy = 25
        
                
        #falling
        if self.vx == 0 and not(up or left or right or down or atk or special or shield) and self.y < plat:
            self.state = "hold"
            self.num = 4
            self.vy = 20
                
        #idle
        if self.vx == 0 and not(up or left or right or down or atk or special or shield) and self.y == plat:
            self.state = "animate"
            self.num = 0
            
        #move left
        if left:
            self.state = "animate"
            self.num = 3
            self.direction = 0
            self.vx = -15 
        else:
            self.vx = 0
            
        #move right 
        if right:
            self.state = "animate"
            self.num = 3
            self.direction = 1
            self.vx = 15
        
                     
        #ducking / ducking attack
        if down and not(up or shield):
            self.state = "hold"
            if self.y < plat:
                self.vy += 25
            if atk:
                self.num = 9
            elif special:
                self.num = 14
            else:
                self.num = 2
        
        #guard
        if shield and not(up or atk):
            self.state = "hold"
            self.num = 1
                
        #attack
        if atk and not(down):
            self.state = "hold"
            if left or right:
                self.num = 7
            elif up:
                self.num = 8
                self.vy += 45
            elif self.y < plat and not (up, left, right):
                self.num = 10    
            else:
                self.num = 6
                
        #special attack
        if special and not (down):
            self.state = "hold"
            if left:
                self.vx = -50
                self.num = 12
            elif right:
                self.vx = 50
                self.num = 12
            elif up:
                self.vy -= 10
                self.num = 13
                if self.actions[self.character][self.direction][13].counter == self.actions[self.character][self.direction][13].counter_limit:
                    self.vy = 25
            else:
                self.state = "animate"
                self.num = 11
            
    
     
