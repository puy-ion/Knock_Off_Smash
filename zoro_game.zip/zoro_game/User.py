from Animation import *
class User:
    def __init__(self, x, y, vx, vy, ay, character, direction, num, actions, state):
        """initiates position, velocity, acceleration, character name, direction facing, which animation, animation list, type of animation""" 
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.ay = ay
        self.character = character
        self.direction = direction
        self.num = num
        self.actions = actions
        self.state = state
        
    def gravity(self, plat):
        """initiates gravity and movement, stops if player is on platform
           parameters: plat = platform
           returns: none"""
        self.x += self.vx
        self.vy += self.ay
        self.y += self.vy
        
        if self.y > plat:
            self.y = plat 
            self.vy = 0
    
    def initiate_action(self):
        """method runs code to animate sprites
           parameters: none
           returns: none""" 
        if self.state == "animate":
            self.actions[self.character][self.direction][self.num].animate(self.x, self.y - self.actions[self.character][self.direction][self.num].image_height)
        else:
            self.actions[self.character][self.direction][self.num].hold(self.x, self.y - self.actions[self.character][self.direction][self.num].image_height)
    
    def moving(self, plat, up, left, right, down, atk, special, shield):
        """based on the controls and position, function will select a sprite
           parameters: plat = platform, up = boolean (keypressed), left = boolean (keypressed), right = boolean (keypressed), down = boolean (keypressed), 
                                        atk = = boolean (keypressed), special = boolean (keypressed), shield = boolean (keypressed)     
           returns: none"""
           
        self.gravity(plat)
        self.initiate_action() 
        
        #idle
        if self.vx == 0 and not(up, left, right, down, atk, special, shield) and self.y == plat:
            self.state = "animate"
            self.num = 0
            
        
        
        
        
    
