class Animation:
    def __init__(self, aimage, image_num, image_width, image_height, counter_delay, counter = 0):
        self.aimage = aimage
        self.image_num = image_num
        self.image_width = image_width
        self.image_height = image_height
        self.counter = counter
        self.counter_delay = counter_delay
        self.counter_limit = image_num -1

    def animate(self, x, y):
        w = (self.counter % self.image_num) * self.image_width
        h = (self.counter / self.image_num) * self.image_height
        copy(self.aimage, w, h, self.image_width, self.image_height, x, y, self.image_width, self.image_height)
        delay(self.counter_delay)
        self.counter += 1
        if self.counter > self.counter_limit:
            self.counter = 0

    
    def hold(self, x, y):
        w = (self.counter % self.image_num) * self.image_width
        h = (self.counter / self.image_num) * self.image_height
        copy(self.aimage, w, h, self.image_width, self.image_height, x, y, self.image_width, self.image_height)
        delay(self.counter_delay)
        self.counter += 1
        if self.counter >= self.counter_limit:
            self.counter = self.counter_limit

            
